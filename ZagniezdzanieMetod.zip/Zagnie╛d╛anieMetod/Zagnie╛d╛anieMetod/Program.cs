﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZagnieżdżanieMetod
{
    internal class Program
    {
        static void Main(string[] args)
        {
            (new Program()).run();
        }

        void run()
        {
            Console.WriteLine("Podaj pierwszy bok: ");
            string bok_a = Console.ReadLine();
            Console.WriteLine("Podaj pierwszy bok: ");
            string bok_b = Console.ReadLine();
            Console.WriteLine("Podaj pierwszy bok: ");
            string bok_c = Console.ReadLine();
            long factoriaValue = Obliczenia(inputValue);
            Console.WriteLine();
        }

        long Obliczenia(int pole)
        {
            int pole = int.Parse(wynik);
            long factorial (long wynik)
            {
                long wynik = 
            }
            return factorialValue;
        }
    }
}
