﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie_kwadrat
{
    
    
        internal class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Podaj długość boku : ");
                int bok = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Pole kwadratu to: " + PoleKwadratu(bok));
            }

            public static int PoleKwadratu(int bok)
            {
                int pole = bok * bok;
                return pole;
            }
        }
    
}
